package com.mycompany.vo;

public class Sign {
//	int id;
//	String name;
}
