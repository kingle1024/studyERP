//package com.mycompany.mapper;
//
//import java.util.List;
//
//import org.apache.ibatis.annotations.Select;
//
//import com.mycompany.vo.Board;
//
//
//public interface BoardMapper {
//	@Select("select * from boards")
//	public List<Board> getBoardList();
//	
//}
