//package com.mycompany.service;
//
//import com.mycompany.exception.EmailExistsException;
//import com.mycompany.resource.User;
//
//public interface UserService {
//	public void create(User user) throws EmailExistsException;
//	public void addAuthority(String email, String authority);
//}
