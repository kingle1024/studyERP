package com.company.myapp;

import java.util.List;
import java.util.Map;
import com.mycompany.vo.User;

public interface UserDao {
	public User selectUserByIdAndPw(User user);

	public int selectTotalCount();

	public int insertUser(User user);

	public List<User> selectUserList(Map<String, Object> map);

}
