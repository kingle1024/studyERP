package com.company.myapp;

import java.util.List;


import com.mycompany.vo.User;

public interface UserService {
	public User getUserByIdAndPw(User user);

	public int getLastPage();

	public List<User> getUserList(int page, String word);

}
