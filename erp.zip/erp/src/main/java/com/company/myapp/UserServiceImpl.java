package com.company.myapp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.vo.User;

@Service
public class UserServiceImpl implements UserService{
	private final int LINE_PER_PAGE = 10;
    @Autowired
    private UserDao userDao;
  
    @Override
    public User getUserByIdAndPw(User user) {
        return userDao.selectUserByIdAndPw(user);
    }
  
    @Override
    public int getLastPage() {
        return (int)(Math.ceil((double)userDao.selectTotalCount()/LINE_PER_PAGE));
    }
  
    @Override
    public List<User> getUserList(int page, String word) {
    	System.out.println("여긴 오니?");
        PageHelper pageHelper = new PageHelper(page,LINE_PER_PAGE);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pageHelper", pageHelper);
        map.put("word", word);
        return userDao.selectUserList(map);
    }
}



