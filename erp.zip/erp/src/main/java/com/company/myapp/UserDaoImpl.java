package com.company.myapp;
import java.util.List;
import java.util.Map;
 
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
 
import com.mycompany.vo.User;

@Repository
public class UserDaoImpl implements UserDao {
	
	private final String NS = "com.company.myapp";
	 @Autowired 
	    private SqlSessionTemplate sqlSession;
	
    @Override
    public User selectUserByIdAndPw(User user) {
        return sqlSession.selectOne(NS+".selectUserByIdAndPw",user);
    }
  
    @Override
    public int selectTotalCount() {
        return sqlSession.selectOne(
                NS+".selectTotalCount");
    }
    @Override
    public int insertUser(User user) {
        return sqlSession.insert(
                NS+".insertUser", user);
    }
    @Override
    public List<User> selectUserList(Map<String, Object> map) {
        return sqlSession.selectList(
                NS+".selectUserList",map);
    }

}
