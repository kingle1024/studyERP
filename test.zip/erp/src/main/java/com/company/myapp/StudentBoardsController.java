package com.company.myapp;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mycompany.mapper.BookMapper;
import com.mycompany.vo.StudentBoard;

import com.mycompany.vo.User;


@Controller
public class StudentBoardsController {
	@Autowired		
	private BookMapper bookMapper;
	
	@RequestMapping(value ="/students", method = RequestMethod.GET)
	public String index1(Model model){
		List<StudentBoard> studentboards = bookMapper.getStudentBoardList();		
		model.addAttribute("studentboards", studentboards);		
		return "students/index";
	}
	
	@RequestMapping(value = "student", method = RequestMethod.POST) // 글쓰기
	public String createStudentBoard(@ModelAttribute StudentBoard studentboard,HttpServletRequest request, Model model){
		bookMapper.createStudent(studentboard);
		return "redirect: " + request.getContextPath() + "/students";
	}

	@RequestMapping(value ="/students/view/{id}", method = RequestMethod.GET)
	public String adminViewBoard(@PathVariable int id, Model model){
		StudentBoard studentboard = bookMapper.getStudentBoard(id);
		model.addAttribute("studentboard", studentboard);
		bookMapper.updateStudentHit(id);
		return "students/view";
	}
	
	@RequestMapping(value ="/students/new")
	public String newStudentBoard(ModelMap model, Principal principal){
		String email = principal.getName(); // 사용자의 아이디(email)를 가져옴
		User user = bookMapper.getUserList(email);
		String name = user.getName();
		model.addAttribute("username", name); // 사용자 이름을 username으로 파싱해줌
		return "students/new";
	}

	@RequestMapping(value = "/student/update", method = RequestMethod.POST) // 수정
	public String update(@ModelAttribute StudentBoard studentboard, HttpServletRequest request) {
	    bookMapper.updateStudent(studentboard);
	    return "redirect: " + request.getContextPath() + "/students";
	}
	
	@RequestMapping(value = "/student/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable int id, Model model) {
	    StudentBoard studentboard = bookMapper.getStudentBoard(id);
	    // 뷰 페이지로 데이터를 전달(key/value 형식)
	    model.addAttribute("studentboard", studentboard);
	    return "students/edit";
	}
	
	@RequestMapping(value = "/student/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable int id){
		bookMapper.deleteStudent(id);
		return "redirect:/students";
	}
}
